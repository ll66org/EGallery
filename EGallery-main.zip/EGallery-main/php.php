phpinfo();
uuyyyy
